package com.tfms.configuration;

public class DatabaseConnection {

}
